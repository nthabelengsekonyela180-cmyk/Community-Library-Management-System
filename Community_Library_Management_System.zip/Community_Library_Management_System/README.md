# Community Library Management System

A full-stack library management application built for the Web Application Development assignment. It contains a React frontend, an Express REST API and a MySQL database.

## Features

- Dashboard with catalogue totals, copies in stock, registered users and low-stock warnings (fewer than 2 copies).
- Book catalogue: add, edit, search and delete books.
- Stock control: record borrowing and restocking. Borrowing is rejected when there are not enough copies.
- Transaction history with date, book, user, type, quantity and notes.
- Membership login using a unique membership ID.
- User administration: add, update and delete Admin and Member accounts.
- Protected API routes, role checks, input validation and database transactions.
- Responsive layout for desktop, tablet and mobile screens.

## Technology

- Frontend: React, Vite, React Router, React Hooks, Fetch API and CSS.
- Backend: Node.js, Express, CORS and JSON Web Tokens.
- Database: MySQL with `mysql2`.

## Requirements

Install Node.js (LTS), npm and MySQL Server. MySQL Workbench is optional.

## 1. Set up the database

1. Start MySQL Server.
2. Open MySQL Workbench or the MySQL command line.
3. Open and run `backend/database/schema.sql`. This creates the `community_library` database and its three tables: `users`, `books` and `transactions`.

## 2. Configure and start the backend

Open a terminal in the `backend` folder:

```bash
npm install
```

Copy `.env.example` to `.env` and edit the database password and JWT secret:

```env
PORT=3000
CLIENT_ORIGIN=http://localhost:5173
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=community_library
JWT_SECRET=use_a_long_random_secret_here
```

Seed demo accounts and sample books:

```bash
npm run seed
```

Start the API:

```bash
npm run dev
```

The API runs at `http://localhost:3000`. Check `http://localhost:3000/api/health` to confirm the API and database connection.

## 3. Start the React frontend

Open a second terminal in the `frontend` folder:

```bash
npm install
```

Copy `.env.example` to `.env` (the default API URL is already correct):

```env
VITE_API_URL=http://localhost:3000/api
```

Start React:

```bash
npm run dev
```

Open the URL printed by Vite, normally `http://localhost:5173`.

## Demo login

The seed script creates these demo accounts:

| Role | Membership ID |
|---|---|
| Administrator | `admin` |
| Member | `member001` |

For this assignment demonstration, membership ID is the login credential. This is a simple classroom authentication flow, not production-grade identity verification. Do not deploy it with real personal data without adding password-based authentication, password hashing, rate limiting and stronger session controls.

## API endpoints

All routes except `GET /api/health` and `POST /api/auth/login` require `Authorization: Bearer <token>`.

| Method | Endpoint | Purpose | Access |
|---|---|---|---|
| GET | `/api/health` | API/database health | Public |
| POST | `/api/auth/login` | Sign in with membership ID | Public |
| GET | `/api/auth/me` | Current signed-in user | Signed in |
| GET | `/api/books` | List books | Signed in |
| POST | `/api/books` | Add a book | Admin |
| PUT | `/api/books/:id` | Update a book | Admin |
| DELETE | `/api/books/:id` | Delete a book | Admin |
| GET | `/api/transactions` | Transaction history | Signed in |
| POST | `/api/transactions` | Borrow or restock; updates stock atomically | Signed in |
| GET | `/api/users` | List users | Signed in |
| POST | `/api/users` | Add a user | Admin |
| PUT | `/api/users/:id` | Update a user | Admin |
| DELETE | `/api/users/:id` | Delete a user | Admin |

### Example transaction body

```json
{
  "bookId": 1,
  "type": "Borrow",
  "quantity": 1,
  "notes": "Borrowed for study"
}
```

Use `"Restock"` as the type to add copies.

## Project structure

```text
Community_Library_Management_System/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── context/
│   │   ├── pages/
│   │   ├── api.js
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── .env.example
│   ├── index.html
│   └── package.json
├── backend/
│   ├── database/schema.sql
│   ├── src/
│   │   ├── middleware/
│   │   ├── routes/
│   │   ├── db.js
│   │   ├── seed.js
│   │   └── server.js
│   ├── .env.example
│   └── package.json
└── README.md
```

## Demonstration checklist

1. Sign in as `admin`.
2. Open Books and add a title. Edit it and then remove a test title.
3. Open Transactions and borrow a copy. Confirm the stock count decreases.
4. Try to borrow more copies than are available. The API should reject the request.
5. Record a Restock transaction. Confirm the stock count increases.
6. Open Users and add a member. Sign out and sign in using that member's membership ID.
7. Return as admin and show the dashboard low-stock indicator.
8. Capture screenshots of the running application and the MySQL `books`, `users` and `transactions` tables for the assignment submission.

## Notes

- The SQL schema uses InnoDB transactions and foreign keys.
- A book's ISBN and a user's membership ID must be unique.
- Deleting a book removes its associated transaction history due to the configured foreign key cascade. Deleting a user with transaction records is restricted to preserve the history.
- Never commit your `.env` file or real credentials to GitHub. Only commit `.env.example`.
